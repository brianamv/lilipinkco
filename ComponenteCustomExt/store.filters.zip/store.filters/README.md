# Hello react typescript

## Configuration
 
1. Ponga esto en el manifest
 
```
    + "nicopoly.filters": "0.x"
```
 