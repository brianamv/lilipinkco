import { useSearchPage } from 'vtex.search-page-context/SearchPageContext'
import { Fragment, useEffect, useState, useMemo } from 'react';
import style from './filters.css';

interface FiltersProps {
    filterName: string;
    imageRoute: string;
}

const Filters = ({ filterName, imageRoute }: FiltersProps) => {

    const { filters } = useSearchPage();
    const [filter, setFilter] = useState([]);

    useEffect(() => {
        if (filters && filters.length) {
            const f = filters.find((f: any) => f.title === filterName);
            setFilter(f?.facets || []);
        }

        return () => {
            setFilter([]);
        }
    }, [filters, filterName]);

    return useMemo(() => {
        if (!filters || !filters.length) return <Fragment />
        return <div className={style.filtersContainer}>{
            filter.map((f, i) => {
                return <a key={i} href={f?.href} className={style.filterLink}>
                    {f?.name}
                    <img className={style.filterImage} src={imageRoute.replace(/{name}/g, f?.name)} />
                </a>
            })
        }</div>
    }, [filter]);
}

Filters.defaultProps = {
    filterName: "Colores",
    imageRoute: "/arquivos/COLOR{name}.jpg"
}

Filters.schema = {
    "title": "admin/filter.title",
    "type": "object",
    "properties": {
        "filterName": {
            "title": "Nombre del filtro",
            "type": "string"
        },
        "imageRoute": {
            "title": "Ruta de la imagen",
            "type": "string"
        }
    }
}

export default Filters
