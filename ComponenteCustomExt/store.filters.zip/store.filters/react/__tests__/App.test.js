test("should true equals true", () => {
  expect(true).toBe(true);
});